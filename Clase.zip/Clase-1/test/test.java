/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


import modelo.dto.Persona;

/**
 *
 * @author Duoc
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            try {
                String rut = "1234567-9";
                String nombre = "El pepe";
                char genero = 'o';
                int edad = 24;
                Persona persona = new Persona(rut, nombre, genero, edad);
                System.out.println(persona.toString());
                
                Persona perso = new Persona("177","a",'y',160);
                perso.imprimir();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            
        }
        
    }
    

