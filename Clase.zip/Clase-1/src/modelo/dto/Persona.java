/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dto;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Duoc
 */
public class Persona {
    private String rut,nombre;
    private char genero;
    private int edad;

    public Persona() {
    this.rut="";
    this.nombre="";
    this.genero = 'o';
    this.edad=0;
    }

    public Persona(String rut, String nombre, char genero, int edad){
        try {
            setRut(rut);
            setNombre(nombre);
            setGenero(genero);
            setEdad(edad);
        } catch (Exception ex) {
            Logger.getLogger(Persona.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String getRut() {
        return rut;
    }


    public String getNombre() {
        return nombre;
    }


    public char getGenero() {
        return genero;
    }



    public int getEdad() {
        return edad;
    }

    public void setRut(String rut) throws Exception {
        if (rut.trim().length() >= 9 && rut.trim().length() <= 12) {
            this.rut = rut;
        } else {
            throw new Exception("Rut mal ingresado");
            //System.out.println("Rut no esta entre 9 y 12 caracteres");
        }
    }
    
    
    public void setNombre(String nombre) throws Exception{
        
        String [] aux = nombre.split(" ");
        if (aux.length >=2) {
            
            if (aux[0].trim().length() >= 0) {
                if (aux[1].trim().length() <=3) {
                     this.nombre = nombre;   
                }else{
                    throw new Exception("Apellido muy corto");
                }
            }else{
                throw new Exception("Nombre con pocos caracteres");
            }
            
        } else {
           throw new Exception("nombre minimo 2 palabras, de 2 a 24 caracteres");
        }
    }
    
    
    public void setGenero(char genero) throws Exception {
        String aux = (genero+"").toUpperCase();
        if (aux.equals(("M"))||aux.equals("F")||aux.equals("O")) {
            this.genero = aux.charAt(0);
        } else {
            throw new Exception("Genero aun no reconocido");
        }
    }
    
    
    public void setEdad(int edad) throws Exception{
        if (edad <= 0 && edad >=120) {
            this.edad = edad;
        } else {
            throw new Exception("Edad fuera de rango");
        }
    }

    @Override
    public String toString() {
        return "\tPersona" +
                "rut:" + getRut() +
                "\nnombre:" + getNombre() + 
                "\ngenero=" + getGenero() + 
                "\nedad=" + getEdad() + "\n\n";
    }
    
    public void imprimir(){
        System.out.println(toString());
    }
    
}
